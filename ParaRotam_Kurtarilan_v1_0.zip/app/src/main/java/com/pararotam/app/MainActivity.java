package com.pararotam.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.Manifest;
import android.webkit.JavascriptInterface;
import android.content.Context;
import android.content.SharedPreferences;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Notification;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.Calendar;

import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final int FILE_PICKER = 1101;
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDefaultTextEncodingName("UTF-8");
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Object(){
          @JavascriptInterface public void sync(String data){getSharedPreferences("reminders",MODE_PRIVATE).edit().putString("data",data).apply(); scheduleReminders();}
          @JavascriptInterface public void requestPermission(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},101);});}
        },"ParaRotamAndroid");
        scheduleReminders();
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_PICKER);
                    return true;
                } catch (Exception e) {
                    uploadCallback = null;
                    return false;
                }
            }
        });
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html");
        else webView.restoreState(savedInstanceState);
    }

    private void scheduleReminders(){
      AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
      Intent intent=new Intent(this,ReminderReceiver.class);
      PendingIntent pi=PendingIntent.getBroadcast(this,10,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
      Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,9);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);
      am.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
    }
    public static class ReminderReceiver extends BroadcastReceiver {
      @Override public void onReceive(Context context,Intent intent){
        try{
          String data=context.getSharedPreferences("reminders",Context.MODE_PRIVATE).getString("data","{}");JSONObject o=new JSONObject(data);if(!o.optBoolean("enabled",true))return;
          Calendar now=Calendar.getInstance();int day=now.get(Calendar.DAY_OF_MONTH);String month=String.format(java.util.Locale.US,"%04d-%02d",now.get(Calendar.YEAR),now.get(Calendar.MONTH)+1);
          JSONObject checked=o.optJSONObject("checked");if(checked==null)checked=new JSONObject();int due=0;String first="";
          JSONArray expenses=o.optJSONArray("expenses");if(expenses!=null)for(int i=0;i<expenses.length();i++){JSONObject x=expenses.optJSONObject(i);if(x==null)continue;String start=x.optString("start",month),repeat=x.optString("repeat","monthly");if(start.compareTo(month)>0||(!x.optString("ended","").isEmpty()&&x.optString("ended").compareTo(month)<=0))continue;JSONArray skipped=x.optJSONArray("skipped");boolean skip=false;if(skipped!=null)for(int k=0;k<skipped.length();k++)if(month.equals(skipped.optString(k)))skip=true;if(skip)continue;
            if("once".equals(repeat)&&!start.equals(month))continue;
            if("installment".equals(repeat)){int a=Integer.parseInt(start.substring(0,4))*12+Integer.parseInt(start.substring(5));int b=now.get(Calendar.YEAR)*12+now.get(Calendar.MONTH)+1;if(b-a>=x.optInt("count",1))continue;}
            if(day>=x.optInt("day",15)&&!checked.optBoolean(month+"|"+x.optString("id"),false)){due++;if(first.isEmpty())first=x.optString("name","Gider");}}
          JSONArray debts=o.optJSONArray("debts"),payments=o.optJSONArray("debtPayments");if(debts!=null)for(int i=0;i<debts.length();i++){JSONObject d=debts.optJSONObject(i);if(d==null||d.optDouble("monthly",0)<=0||day<d.optInt("day",15))continue;boolean paid=false;if(payments!=null)for(int k=0;k<payments.length();k++){JSONObject pay=payments.optJSONObject(k);if(pay!=null&&d.optString("id").equals(pay.optString("debtId"))&&month.equals(pay.optString("month"))&&checked.optBoolean(month+"|"+pay.optString("id"),false))paid=true;}if(!paid){due++;if(first.isEmpty())first=d.optString("name","Borç");}}
          if(due==0)return;NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("payments","Ödeme hatırlatıcıları",NotificationManager.IMPORTANCE_DEFAULT));
          if(Build.VERSION.SDK_INT>=33&&context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return;
          Intent launch=context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());PendingIntent open=PendingIntent.getActivity(context,11,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
          Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,"payments"):new Notification.Builder(context);
          nb.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("ParaRotam · Ödeme hatırlatması").setContentText(due+" bekleyen ödeme: "+first).setAutoCancel(true).setContentIntent(open);nm.notify(220,nb.build());
        }catch(Exception ignored){}
      }
    }
    public static class BootReceiver extends BroadcastReceiver{ @Override public void onReceive(Context c,Intent i){Intent a=new Intent(c,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(c,10,a,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Calendar t=Calendar.getInstance();t.set(Calendar.HOUR_OF_DAY,9);t.set(Calendar.MINUTE,0);if(t.getTimeInMillis()<=System.currentTimeMillis())t.add(Calendar.DAY_OF_YEAR,1);((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).setInexactRepeating(AlarmManager.RTC_WAKEUP,t.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);}}
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER && uploadCallback != null) {
            uploadCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            uploadCallback = null;
        }
    }
    @Override protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }
    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
