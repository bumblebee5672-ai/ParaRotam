ParaRotam v1.0 — kurtarılan maaş zamları kaynak paketinden hazırlanmıştır. Arayüz ve simgeler korunmuştur. GitHub Actions APK derlemesi doğrulanmalıdır.
